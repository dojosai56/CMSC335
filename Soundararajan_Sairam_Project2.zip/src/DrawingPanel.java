/**
 * Name: Sairam Soundararajan
 * Date: 11-14-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The DrawingPanel class allows the user to enter the shape's respective measurement aspects
 * to calculate the area of a 2D shape and the volume of a 3D shape.
 * This will either draw the 2D shape based on the area values inputted by user on the GUI or
 * display an image of the 3D shape from file input regardless of volume on the GUI
 */
import javax.swing.JPanel;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

public class DrawingPanel extends JPanel {

    private int panel_height, panel_width;
    BufferedImage canvas;

    public DrawingPanel(int width, int height){
        super();
        this.setPreferredSize(new Dimension(width, height));
    } // constructor

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        if (canvas == null) {
            int w = this.getWidth();
            int h = this.getHeight();

            canvas = (BufferedImage)(this.createImage(w, h));
        }

        draw(g2d);
    } // paintComponent

    private void draw(Graphics2D g2d) {
        if(canvas == null)
            return;
        g2d.drawImage(canvas, panel_width, panel_height, this);
    } // draw

    public <T extends Shape> void draw(T shape){
        if(canvas == null){
            return;
        }


        // code to draw onto to canvas bufferedImage
        Graphics2D bImgG2d = canvas.createGraphics();

        bImgG2d.setColor(Color.WHITE);
        bImgG2d.fillRect(0,0, canvas.getWidth(), canvas.getHeight());
        bImgG2d.setColor(Color.BLACK);
        shape.draw(bImgG2d);

        repaint(); // calls the paintComponent to repaint
    } // draw

}
