import java.awt.*;
import java.util.ArrayList;

/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Circle Class is a TwoDimensionalShape which uses the measurement of a radius in order to calculate the area.
 */
public class Circle extends TwoDimensionalShape{

    double radius;

    public Circle()
    {
        setRadius(0.0);
    }

    public Circle(double radius)
    {
        setRadius(radius);
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getRadius()
    {
        return radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * (Math.pow(getRadius(), 2));
    }

    @Override
    public String toString() {
        return "Circle{" + "Area=" + calculateArea() + "radius=" + radius + '}';
    }

    @Override
    public ArrayList<ShapeDimension> getAttributeList() {
        ArrayList<ShapeDimension> list = new ArrayList<ShapeDimension>();

        list.add(new ShapeDimension("radius", this.radius));

        return list;
    } // getAttributeList

    @Override
    public void setAttributeList(ArrayList<ShapeDimension> newList) {

        for(ShapeDimension s : newList){
            if(s.name.equals("radius"))
                this.radius = s.value;
        } // loop through attributes of the list

    } // setAttributeList

    @Override
    public void draw(Graphics2D g2d) {
        g2d.drawOval((int)this.x, (int)this.y, (int)this.radius*2, (int)this.radius*2);
    }
}
