import java.awt.*;
import java.util.ArrayList;

/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Square Class is a TwoDimensionalShape which uses the measurement of a single length in order to calculate the area.
 */
public class Square extends TwoDimensionalShape{

    double length;

    public Square()
    {
        setLength(0.0);
    }

    public Square(double length)
    {
        setLength(length);
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getLength()
    {
        return length;
    }

    @Override
    public double calculateArea() {
        return Math.pow(getLength(), 2);
    }

    @Override
    public ArrayList<ShapeDimension> getAttributeList() {
        ArrayList<ShapeDimension> list = new ArrayList<ShapeDimension>();

        list.add(new ShapeDimension("length", this.length));

        return list;
    } // getAttributeList

    @Override
    public void setAttributeList(ArrayList<ShapeDimension> newList) {

        for (ShapeDimension s : newList) {
            if (s.name.equals("length"))
                this.length = s.value;
        } // loop through attributes of the list
    } // setAttributeList

    @Override
    public void draw(Graphics2D g2d) {
        g2d.drawRect((int)this.x, (int)this.y, (int) length, (int) length);
    }

    @Override
    public String toString() {
        return "Square{" + "Area=" + calculateArea() + "length=" + length + '}';
    }
}
