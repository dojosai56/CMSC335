/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Shape Class is the fundamental parent class where all the 2D and 3D shapes inherit from.
 */
import java.awt.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

public abstract class Shape {
    int numOfDimensions;
    double x, y;

    @Override
    public String toString() {
        return "Shape{" + "numOfDimensions=" + numOfDimensions + '}';
    }


    public abstract ArrayList<ShapeDimension> getAttributeList();

    public abstract void setAttributeList(ArrayList<ShapeDimension> newList);

    public abstract void draw(Graphics2D g2d);

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }
}
