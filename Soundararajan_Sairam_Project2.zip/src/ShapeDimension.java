/**
 * Name: Sairam Soundararajan
 * Date: 11-14-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The ShapeDimension class takes in the shape name and value into the constructor
 */
public class ShapeDimension {
    public String name;
    public double value;

    public ShapeDimension(String name, double value){
        this.name = name;
        this.value = value;
    }
}
