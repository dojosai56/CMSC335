import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Name: Sairam Soundararajan
 * Date: 11-14-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The ThreeDimensionalShape is a subclass of the Shape class that calculates the volume of 3D shapes.
 */
public abstract class ThreeDimensionalShape extends Shape{
    double volume;
    protected Image img;
    public abstract double calculateVolume();

    public void setImage(String path){
        try {
            img = ImageIO.read(new File(path));
        }catch(Exception e) {
            System.out.println("File not found! :(");
        }
    }

    public void draw(Graphics2D g){
        g.drawImage(img, (int)this.x, (int)this.y, null);
    } // draw

}
