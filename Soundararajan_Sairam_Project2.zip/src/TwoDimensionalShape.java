/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The TwoDimensionalShape is a subclass of the Shape class that calculates the volume of 2D shapes.
 */
public abstract class TwoDimensionalShape extends Shape{
    double area;

    public double getArea() {
        return area;
    }

    public abstract double calculateArea();


}
