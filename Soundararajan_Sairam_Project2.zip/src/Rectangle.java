import java.awt.*;
import java.util.ArrayList;

/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Rectangle Class is a TwoDimensionalShape that uses the
 * measurement of a length and width in order to calculate the area.
 */
public class Rectangle extends TwoDimensionalShape{

    double length;
    double width;

    public Rectangle()
    {
        setLength(0.0);
        setWidth(0.0);
    }

    public Rectangle(double length, double width)
    {
        setLength(length);
        setWidth(width);
    }

    public void setLength(double length)
    {
        this.length = length;
    }

    public void setWidth(double width)
    {
        this.width = width;
    }

    public double getLength()
    {
        return length;
    }

    public double getWidth() {
        return width;
    }

    @Override
    public double calculateArea() {
        return length * width;
    }

    @Override
    public ArrayList<ShapeDimension> getAttributeList() {
        ArrayList<ShapeDimension> list = new ArrayList<ShapeDimension>();

        list.add(new ShapeDimension("length", this.length));
        list.add(new ShapeDimension("width", this.width));

        return list;
    } // getAttributeList

    @Override
    public void setAttributeList(ArrayList<ShapeDimension> newList) {

        for (ShapeDimension s : newList) {
            if (s.name.equals("length"))
                this.length = s.value;
            if (s.name.equals("width"))
                this.width = s.value;
        } // loop through attributes of the list
    } // setAttributeList

    @Override
    public void draw(Graphics2D g2d) {
        g2d.drawRect((int)this.x, (int)this.y, (int) length, (int) width);
    }

    @Override
    public String toString() {
        return "Rectangle{" + "Area=" + calculateArea() + "length=" + length + ", width=" + width + '}';
    }
}
