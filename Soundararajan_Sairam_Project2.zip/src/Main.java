/**
 * Name: Sairam Soundararajan
 * Date: 11-14-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Main class, unlike the Driver class in Project 1, is the main class that will run the GUI made up of AWT and
 * Swing components. It relies on DrawingPanel, ShapeDimension, and all the objects of the Shape class. The main purpose of the
 * Main class is to have the user input values for the measurement aspects of a shape and then display the respective shape.
 * The 2D class will draw the shape based on the values the user inputs for the area of that shape.
 * Note that for the 3D shape, the user's input for the values of the shape volume will have no effect for the size and
 * measurement of the shape being displayed since it uses a BufferedImage from file input. Thus, it will not draw the 3D shape
 * like it did for 2D.
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.*;


public class Main {

	private JFrame frame;
	private DrawingPanel panel;
	private JMenuBar menubar_main;
	private JMenu menu_shape;
	private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");
	/*
	 * Default Constructor
	 * Builds the application GUI
	 */
	public Main() {
		frame = new JFrame("Java 00 Shapes");
		// main panel 
		panel = new DrawingPanel(800,600);
		// create menu bar
		menubar_main = new JMenuBar();
		// create menu for shapes on menubar_main
		createShapeMenu();
		
		frame.add(panel);
		
		frame.setJMenuBar(menubar_main);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		frame.pack(); //setSize(800,600);
		frame.setVisible(true);
	} // constructor
	
	/*
	 * createShapeMenu()
	 * Creates the menu for the Shapes and adds it to the
	 * main menu bar 
	 */
	private void createShapeMenu() {
		JMenu submenu_3dshapes, submenu_2dshapes;
		// initialize shape menu
		menu_shape = new JMenu("Shapes");	
		// --- 3d shapes sub menu ---	
		submenu_3dshapes = new JMenu("3D");
		// initialize each 3d shape menu item
		JMenuItem menuItem_cone = new JMenuItem("cone");
		JMenuItem menuItem_cube = new JMenuItem("cube");
		JMenuItem menuItem_cylinder = new JMenuItem("cylinder");	
		JMenuItem menuItem_sphere = new JMenuItem("sphere");	
		JMenuItem menuItem_torus = new JMenuItem("torus");
		// add Action Listeners to each 3d shape menu item		
		menuItem_cone.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Cone cone = new Cone();
				cone.setImage("img/cone.jpg");
				buildShapeEditorMenu(cone);
				
			} // actionPerformed
			
		});
		menuItem_cube.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Cube cube = new Cube();
				cube.setImage("img/cube.png");
				buildShapeEditorMenu(cube);
				
			} // actionPerformed
			
		});
		menuItem_cylinder.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Cylinder cylinder = new Cylinder();
				cylinder.setImage("img/cylinder.jpg");
				buildShapeEditorMenu(cylinder);
				
			} // actionPerformed
			
		});
		menuItem_sphere.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Sphere sphere = new Sphere();
				sphere.setImage("img/sphere.jpg");
				buildShapeEditorMenu(sphere);
				
			} // actionPerformed
			
		});
		menuItem_torus.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Torus torus = new Torus();
				torus.setImage("img/torus.jpg");
				buildShapeEditorMenu(torus);
				
			} // actionPerformed
			
		});
		// adding 3d shapes menu items to 3d shapes submenu
		submenu_3dshapes.add(menuItem_cone);
		submenu_3dshapes.add(menuItem_cube);
		submenu_3dshapes.add(menuItem_cylinder);
		submenu_3dshapes.add(menuItem_sphere);
		submenu_3dshapes.add(menuItem_torus);
		//  --- 2d shape sub menu ---
		submenu_2dshapes = new JMenu("2D");
		// initialize each 2d shape menu item
		JMenuItem menuItem_circle = new JMenuItem("circle");
		JMenuItem menuItem_square = new JMenuItem("square");	
		JMenuItem menuItem_rectangle = new JMenuItem("rectangle");	
		JMenuItem menuItem_triangle = new JMenuItem("triangle");
		// add actionListeners to each menuItem
		menuItem_circle.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				buildShapeEditorMenu(new Circle());

				
			} // actionPerformed
			
		});
		menuItem_square.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				buildShapeEditorMenu(new Square());
				
			} // actionPerformed
			
		});
		menuItem_rectangle.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				buildShapeEditorMenu(new Rectangle());
				
			} // actionPerformed
			
		});
		menuItem_triangle.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				buildShapeEditorMenu(new Triangle());
				
			} // actionPerformed
			
		});
		// add items to menu
		submenu_2dshapes.add(menuItem_circle);
		submenu_2dshapes.add(menuItem_square);
		submenu_2dshapes.add(menuItem_rectangle);
		submenu_2dshapes.add(menuItem_triangle);	
		// add sub menus to menu
		menu_shape.add(submenu_3dshapes);
		menu_shape.add(submenu_2dshapes);
		// add menu to main menu bar
		menubar_main.add(menu_shape);	
	} // createMenu
	
	/*
	 * buildShapeEditorMenu(T shape)
	 * A generic method which accepts an object that extends the shape class
	 * Takes the list of attributes for the given shape and constructs a GUI
	 * that allows editing of those attributes.
	 */
	private <T extends Shape> void buildShapeEditorMenu(T shape) {

		ArrayList<ShapeDimension> attributes = shape.getAttributeList();

		JDialog shapeEditor_dialog = new JDialog();
		shapeEditor_dialog.setTitle(shape.getClass().getName());

		
		JPanel attributeMenu = new JPanel(new GridBagLayout());
		
		String shapeCalculation =""; 
		if(shape instanceof TwoDimensionalShape) {
			shapeCalculation = "area: " + decimalFormat.format(((TwoDimensionalShape) shape).calculateArea());
		}else if(shape instanceof ThreeDimensionalShape) {
			shapeCalculation ="volume: " +  decimalFormat.format(((ThreeDimensionalShape) shape).calculateVolume());
		}
		JLabel shapeCalc_label = new JLabel(shapeCalculation);
		
		GridBagConstraints constraint = new GridBagConstraints();
		
		int gridRow = 0; // specify upper left row of component in gridLayout 

		// create label for X coordinate
		JLabel xLabel = new JLabel("X");
		constraint.gridx = 0;
		constraint.gridy = gridRow;
		attributeMenu.add(xLabel, constraint);
		// create textfield to set value of attribute
		JTextField xField = new JTextField("0" + "", 5);
		constraint.gridx = 1;
		constraint.gridy = gridRow++;
		attributeMenu.add(xField, constraint);
		// create label for Y coordinate
		JLabel yLabel = new JLabel("Y");
		constraint.gridx = 0;
		constraint.gridy = gridRow;
		attributeMenu.add(yLabel, constraint);
		// create textfield to set value of attribute
		JTextField yField = new JTextField("0" + "", 5);
		constraint.gridx = 1;
		constraint.gridy = gridRow++;
		attributeMenu.add(yField, constraint);
		// add listeners for xField and yField
		xField.addActionListener(new ActionListener(){

			/**
			 * Invoked when an action occurs.
			 *
			 * @param arg0
			 */
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					double xCoordinate = Double.parseDouble(xField.getText());
					shape.setX(xCoordinate);
					panel.draw(shape);
				}catch(Exception e){
					showErrorDialog("Coordinates must be positive real number");
				}
			}
		});

		yField.addActionListener(new ActionListener(){

			/**
			 * Invoked when an action occurs.
			 *
			 * @param arg0
			 */
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					double yCoordinate = Double.parseDouble(yField.getText());
					shape.setY(yCoordinate);
					panel.draw(shape);
				}catch(Exception e){
					showErrorDialog("Coordinates must be positive real number");
				}
			}
		});


		for(ShapeDimension attrb : attributes) {
			// create label for attribute
			JLabel attrbLabel = new JLabel(attrb.name);
			constraint.gridx = 0;
			constraint.gridy = gridRow;		
			attributeMenu.add(attrbLabel, constraint);
			// create textfield to set value of attribute
			JTextField valueField = new JTextField(attrb.value + "", 5);
			valueField.setName(attrb.name);
			constraint.gridx = 1;
			constraint.gridy = gridRow;
			attributeMenu.add(valueField, constraint);
			
			valueField.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					String text = valueField.getText();
					
					try {
						double newValue = Double.parseDouble(text);
						
						// update the attributes list that we got from the shape
						updateShapeAttribute(attributes, valueField.getName(), newValue);
						// send the updated attribute list back to the shape
						shape.setAttributeList(attributes);
						// calc area or volume
						String shapeCalculation = "";
						// add volume or area calulation as label
						if(shape instanceof TwoDimensionalShape) {
							shapeCalculation = "area: " + decimalFormat.format(((TwoDimensionalShape) shape).calculateArea());
						}else if(shape instanceof ThreeDimensionalShape) {
							shapeCalculation ="volume: " +  decimalFormat.format(((ThreeDimensionalShape) shape).calculateVolume());
						}
						
						shapeCalc_label.setText(shapeCalculation);
						panel.draw(shape);
					}catch(Exception e) {
						showErrorDialog("Input must be a Positive real number.");
					}

				} // actionPerformed

				private void updateShapeAttribute(ArrayList<ShapeDimension> attributes, String name, double newValue) {
					for(ShapeDimension d : attributes) {
						if(d.name.equals(name)) {
							d.value = newValue;
						}
					}
					
				}
				
			}); // add listener to textField
			
			gridRow++;
		} // loop through each attribute of shape and create label and textField for it
		
		// add shape calculation (either area or volume)
		constraint.gridx = 0;
		constraint.gridy = gridRow;	
		attributeMenu.add(shapeCalc_label, constraint);

		shapeEditor_dialog.add(attributeMenu);
		shapeEditor_dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		shapeEditor_dialog.pack();
		shapeEditor_dialog.setVisible(true);
		
		shapeEditor_dialog.add(attributeMenu);
	} // buildShapeEditorMenu
	
	/*
	 * Displays a dialog with the given message
	 * used for any user errors
	 */
	private void showErrorDialog(String msg) {
		JOptionPane.showMessageDialog(new JFrame(), msg, "Dialog",
				JOptionPane.ERROR_MESSAGE);
	} // showErrorDialog
	
	public static void main(String [] args) {
		new Main(); // call Main constructor which will build and show gui
	} // main
	
} // Main