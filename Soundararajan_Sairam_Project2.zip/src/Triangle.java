import java.awt.*;
import java.util.ArrayList;

/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 2
 * Description: The Triangle Class is a TwoDimensionalShape which uses the measurement of a base and height
 * in order to calculate the area.
 */
public class Triangle extends TwoDimensionalShape{

    double base;
    double height;

    public Triangle()
    {
        setBase(0.0);
        setHeight(0.0);
    }

    public Triangle(double base, double height)
    {
        setBase(base);
        setHeight(height);
    }

    public void setBase(double base) {
        this.base = base;
    }

    public void setHeight(double height){
        this.height = height;
    }

    public double getBase() {
        return base;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public double calculateArea() {
        return (getBase() * getHeight()) / 2;
    }

    @Override
    public ArrayList<ShapeDimension> getAttributeList() {
        ArrayList<ShapeDimension> list = new ArrayList<ShapeDimension>();

        list.add(new ShapeDimension("base", this.base));
        list.add(new ShapeDimension("height", this.height));

        return list;
    } // getAttributeList

    @Override
    public void setAttributeList(ArrayList<ShapeDimension> newList) {

        for (ShapeDimension s : newList) {
            if (s.name.equals("base"))
                this.base = s.value;
            if (s.name.equals("height"))
                this.height = s.value;
        } // loop through attributes of the list
    } // setAttributeList

    @Override
    public void draw(Graphics2D g2d) {
        g2d.drawLine((int)(x - 0.5 * base), (int)(y+height), (int)x, (int)y);
        g2d.drawLine((int)x, (int)y, (int)(x + 0.5 * base), (int)(y+height));
        g2d.drawLine((int)(x - 0.5 * base), (int)(y+height), (int)(x + 0.5 * base), (int)(y+height));

    }

    @Override
    public String toString() {
        return "Triangle{" + "Area=" + calculateArea() + "base=" + base + ", height=" + height + '}';
    }
}
