package SimulationObjects;

import java.util.ArrayList;

public interface CarNetworkCallbackFunction {
	public void updateGUI(String[] cars);
}
