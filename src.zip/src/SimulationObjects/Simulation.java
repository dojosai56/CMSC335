package SimulationObjects;

/**
 * Class the controls the traffic intersection 
 */
public class Simulation{
	/* simulation state */
	static enum State {STOPPED, RUNNING, PAUSED}
	private State state;
	
	// simulation threads 
	private Thread trafficLightNetwork_thread;
	private Thread clock_thread;
	private Thread carNetwork_thread;
	
	// simulation objects
	private Clock clock;
	private TrafficLightNetWork trafficLights;
	private CarNetwork cars;
	
	public void initialize(ClockCallbackFunction updateGUI_clock, TrafficNetworkCallbackFunction updateGUI_trafficLights, CarNetworkCallbackFunction updateGUI_cars) {
		clock = new Clock(updateGUI_clock);
		trafficLights = new TrafficLightNetWork(updateGUI_trafficLights, clock);
		cars = new CarNetwork(3, clock, trafficLights, updateGUI_cars);
		
		clock_thread = new Thread(clock);
		trafficLightNetwork_thread = new Thread(trafficLights);
		carNetwork_thread = new Thread(cars);
		
		clock_thread.start();
		
		trafficLightNetwork_thread.start();
		carNetwork_thread.start();
	} // initialize
	
	public void start() {
		
	} // start
	
	public void pause() {
		
	} // pause
	
	public void stop() {
		
	} // stop
	
	public void resume() {
		
	} // resume

} // Simulation
