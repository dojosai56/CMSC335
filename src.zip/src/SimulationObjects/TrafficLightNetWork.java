package SimulationObjects;

import java.util.ArrayList;

import SimulationObjects.Simulation.State;

/**
 * 
 * Maintains a network of traffic lights 
 * 
 * Features
 *  -> 1D network of TrafficLights
 *  -> RealTime 
 *  Requirements:
 *   -> 
 * 
 *     
 */
public class TrafficLightNetWork implements Runnable{
	private TrafficNetworkCallbackFunction callback;
	private Simulation.State state;
	private Clock clock;
	private ArrayList<TrafficLight> lights;
	
	public TrafficLightNetWork(TrafficNetworkCallbackFunction f, Clock clock) {
		callback = f;
		this.clock = clock;
		lights = new ArrayList<TrafficLight>();
		
		
		//for(int i = 0; i < 3;i++) {
			lights.add(new TrafficLight(1000 + (1000 * 0),0,10));
			lights.add(new TrafficLight(1000 + (1000 * 1),0,5));
			lights.add(new TrafficLight(1000 + (1000 * 2),0,5));
		//}
	}
	@Override
	public void run() {
		System.out.println("traffic network started");
		state = Simulation.State.RUNNING;
		
		long currentTime, elapsedTime;
		long lastUpdateTime = clock.getTimeInSeconds();
		boolean updateSuccessful = false;
		while(state != State.STOPPED) {
			
			currentTime = clock.getTimeInSeconds();
			//elapsedTime = currentTime - lastUpdateTime;
			//System.out.println(elapsedTime + "," + currentTime + "," + lastUpdateTime);
			//System.out.println(currentTime);
			
			for(TrafficLight light : lights) {
				if(light.updateState(currentTime)) {
					updateSuccessful = true;
					light.setLastUpdateTime(clock.getTimeInSeconds());
					//lastUpdateTime = clock.getTimeInSeconds();
					//System.out.println(light.getState().toString());
				} 
			} // loop through each light
			
			if(updateSuccessful) {
				callback.updateGUI(lights);
				updateSuccessful = false;
			}
			
		}// timing loop to update each traffic light's state
		
	}
	
	public synchronized ArrayList<TrafficLight> getLights() {
		return lights;
	}
	
	
} // TrafficLightThread
