package SimulationObjects;

import java.util.ArrayList;

public interface TrafficNetworkCallbackFunction {
	public void updateGUI(ArrayList<TrafficLight> lights);
}
