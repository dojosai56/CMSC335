package SimulationObjects;

public interface ClockCallbackFunction {
	public void updateGUI(String date);
} // ClockCallbackFunction
