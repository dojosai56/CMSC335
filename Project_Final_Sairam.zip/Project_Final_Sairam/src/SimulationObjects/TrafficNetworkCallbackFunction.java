package SimulationObjects;

import java.util.List;

public interface TrafficNetworkCallbackFunction {
	public void updateGUI(List<TrafficLight> lights);
}
