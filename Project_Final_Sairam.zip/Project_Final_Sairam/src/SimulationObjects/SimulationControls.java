package SimulationObjects;

public interface SimulationControls {

}
