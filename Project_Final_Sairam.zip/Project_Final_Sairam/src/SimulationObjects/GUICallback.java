package SimulationObjects;

public class GUICallback {

}
