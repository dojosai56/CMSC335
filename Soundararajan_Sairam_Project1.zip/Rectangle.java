/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Rectangle Class is a TwoDimensionalShape that uses the
 * measurement of a length and width in order to calculate the area.
 */
public class Rectangle extends TwoDimensionalShape{

    double length;
    double width;

    public Rectangle()
    {
        setLength(0.0);
        setWidth(0.0);
    }

    public Rectangle(double length, double width)
    {
        setLength(length);
        setWidth(width);
    }

    public void setLength(double length)
    {
        this.length = length;
    }

    public void setWidth(double width)
    {
        this.width = width;
    }

    public double getLength()
    {
        return length;
    }

    public double getWidth() {
        return width;
    }

    @Override
    public double calculateArea() {
        return length * width;
    }

    @Override
    public String toString() {
        return "Rectangle{" + "Area=" + calculateArea() + "length=" + length + ", width=" + width + '}';
    }
}
