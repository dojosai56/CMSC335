/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Square Class is a TwoDimensionalShape which uses the measurement of a single length in order to calculate the area.
 */
public class Square extends TwoDimensionalShape{

    double length;

    public Square()
    {
        setLength(0.0);
    }

    public Square(double length)
    {
        setLength(length);
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getLength()
    {
        return length;
    }

    @Override
    public double calculateArea() {
        return Math.pow(getLength(), 2);
    }

    @Override
    public String toString() {
        return "Square{" + "Area=" + calculateArea() + "length=" + length + '}';
    }
}
