/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Torus Class is a ThreeDimensionalShape which
 * uses the measurement of a minor radius and major radius in order to calculate the volume.
 * (Fun Fact: A doughnut is in the shape of a Torus)
 */
public class Torus extends ThreeDimensionalShape{
    double volume;
    double minorRad;
    double majorRad;

    public Torus()
    {
        setMinorRad(0.0);
        setMajorRad(0.0);
    }

    public Torus(double minorRad, double majorRad)
    {
        setMinorRad(minorRad);
        setMajorRad(majorRad);
    }

    public void setMinorRad(double minorRad) {
        this.minorRad = minorRad;
    }

    public void setMajorRad(double majorRad)
    {
        this.majorRad = majorRad;
    }

    public double getMinorRad() {
        return minorRad;
    }

    public double getMajorRad() {
        return majorRad;
    }

    @Override
    public double calculateVolume() {
        volume = 2;
        return ((Math.PI * (Math.pow(getMinorRad(), 2))) * (volume * Math.PI * getMajorRad()));
    }

    @Override
    public String toString() {
        return "Torus{" + "Volume=" + calculateVolume() + " minorRad=" + minorRad + ", majorRad=" + majorRad + '}';
    }
}

