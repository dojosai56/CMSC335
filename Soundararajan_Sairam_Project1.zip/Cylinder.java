/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Cylinder Class is a ThreeDimensionalShape which uses the measurement
 * of a radius and height in order to calculate the volume.
 */
public class Cylinder extends ThreeDimensionalShape{
    double radius;
    double height;

    public Cylinder()
    {
        setRadius(0.0);
        setHeight(0.0);
    }

    public Cylinder(double radius, double height)
    {
        setRadius(radius);
        setHeight(height);
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getRadius() {
        return radius;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public double calculateVolume() {
        return (Math.PI * Math.pow(getRadius(), 2) * getHeight());
    }

    @Override
    public String toString() {
        return "Cylinder{" + "Volume=" + calculateVolume() + "radius=" + radius + ", height=" + height + '}';
    }
}
