/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Shape Class is the fundamental parent class where all the 2D and 3D shapes inherit from.
 */
public class Shape {

    int numOfDimensions;

    @Override
    public String toString() {
        return "Shape{" + "numOfDimensions=" + numOfDimensions + '}';
    }
}
