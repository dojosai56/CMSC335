/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Driver class is the main class that accesses all the shapes objects
 * to calculate the volume or area based on user input.
 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Driver {

    private static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        int value;
        System.out.println("*********Welcome to the Java OO Shapes Program **********");
        System.out.println("Select from the menu below:");

        while (running) {
            // display menu
            displayMenu();

            while(true) {
                try {

                    // read in the value
                    value = scan.nextInt();


                    switch (value) {
                        case 1:
                            constructCircle();
                            break;
                        case 2:
                            constructRectangle();
                            break;
                        case 3:
                            constructSquare();
                            break;
                        case 4:
                            constructTriangle();
                            break;
                        case 5:
                            constructSphere();
                            break;
                        case 6:
                            constructCube();
                            break;
                        case 7:
                            constructCone();
                            break;
                        case 8:
                            constructCylinder();
                            break;
                        case 9:
                            constructTorus();
                            break;
                        case 10:
                            LocalDateTime date = LocalDateTime.now();
                            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                            String formattedDate = date.format(myFormatObj);
                            System.out.println("Thanks for using the program. Today is " + formattedDate);
                            running = false;
                            break;
                        default:


                    } // do something based on value

                } catch (Exception e)
                {
                    System.out.println("Invalid entry! Please type in a number between 1 and 10");
                    scan.next();
                }
            }

        } // loop

    } // main

    private static void constructRectangle() {
        double length, width;

        System.out.println("You selected a Rectangle.");

        length = promptForDimension("What is the length?");

        width = promptForDimension("What is the width?");

        Rectangle shape = new Rectangle(length, width);
        System.out.println("The area is: " + shape.calculateArea());
    }

    private static void constructTorus() {
        double minor, major;

        System.out.println("You selected a Torus.");

        major = promptForDimension("What is the major radius?");

        minor = promptForDimension("What is the minor radius?");

        Torus shape = new Torus(minor, major);
        System.out.println("The volume is: " + shape.calculateVolume());
    } // constructTorus

    private static void constructCylinder() {
        double r, height;

        System.out.println("You selected a Sphere.");

        r = promptForDimension("What is the base radius?");

        height = promptForDimension("What is the height?");

        Cylinder shape = new Cylinder(r, height);
        System.out.println("The volume is: " + shape.calculateVolume());

    } // constructCylinder

    private static void constructCone() {
        double r, height;

        System.out.println("You selected a Cone.");

        r = promptForDimension("What is the base radius?");

        height = promptForDimension("What is the cone height?");

        Cone shape = new Cone(r, height);
        System.out.println("The volume is: " + shape.calculateVolume());

    } // constructCone

    private static void constructCube() {
        double length, width, height;

        System.out.println("You selected a Cube.");

        length = promptForDimension("What is the side length?");

        Cube shape = new Cube(length);
        System.out.println("The volume is: " + shape.calculateVolume());

    } // constructCube

    private static void constructSphere() {
        double r;

        System.out.println("You selected a Sphere.");

        r = promptForDimension("What is the radius?");

        Sphere shape = new Sphere(r);
        System.out.println("The volume is: " + shape.calculateVolume());

    } // constructSphere

    private static void constructTriangle() {
        double base, height;

        System.out.println("You selected a Triangle.");

        base = promptForDimension("What is the base?");

        height = promptForDimension("What is the height?");

        Triangle shape = new Triangle(base, height);
        System.out.println("The area is: " + shape.calculateArea());

    } // constructTriangle

    private static void constructSquare() {
        double length;

        System.out.println("You selected a Square.");

        length = promptForDimension("What is the length?");

        Square shape = new Square(length);
        System.out.println("The area is: " + shape.calculateArea());

    } // constructSquare

    private static void constructCircle() {
        double r;

        System.out.println("You selected a Circle.");

        r = promptForDimension("What is the radius?");

        Circle shape = new Circle(r);
        System.out.println("The area is: " + shape.calculateArea());

    } // constructCircle

    private static void displayMenu() {

        System.out.println("1. Construct a Circle");
        System.out.println("2. Construct a Rectangle");
        System.out.println("3. Construct a Square");
        System.out.println("4. Construct a Triangle");
        System.out.println("5. Construct a Sphere");
        System.out.println("6. Construct a Cube");
        System.out.println("7. Construct a Cone");
        System.out.println("8. Construct a Cylinder");
        System.out.println("9. Construct a Torus");
        System.out.println("10. Exit the program");

    } // displayMenu

    private static double promptForDimension(String prompt) {
        double d;
        while(true) {
            try {
                System.out.println(prompt);
                d = scan.nextDouble();
                if (d < 0)
                    System.out.println("Please enter a positive real number (ex. 3.5).");
                else
                    return d;
            }catch(Exception e) {
                System.out.println("Please enter a positive real number (ex. 3.5).");
                scan.next(); // remove the bad char from input buffer
            }

        }
    }
} // Driver
