/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Cube Class is a ThreeDimensionalShape which uses the measurement of a side(length/width same measurement)
 * in order to calculate the volume.
 */
public class Cube extends ThreeDimensionalShape{

    double side;

    public Cube()
    {
        setSide(0.0);
    }

    public Cube(double side)
    {
        setSide(side);
    }

    public void setSide(double side) {
        this.side = side;
    }

    public double getSide()
    {
        return side;
    }

    @Override
    public double calculateVolume()
    {
        return Math.pow(getSide(), 3);
    }

    @Override
    public String toString() {
        return "Volume=" + calculateVolume() + "Cube{" + "side=" + side + '}';
    }
}
