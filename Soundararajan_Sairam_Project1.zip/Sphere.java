/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Sphere Class is a ThreeDimensionalShape which uses the measurement of a radius in order to calculate the volume.
 */
public class Sphere extends ThreeDimensionalShape{

    double radius;
    double volume;

    public Sphere()
    {
        setRadius(0.0);
    }

    public Sphere(double radius)
    {
        setRadius(radius);
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }


    @Override
    public double calculateVolume() {
        volume = 4/3;
        return ((volume) * Math.PI) * (Math.pow(getRadius(),3));
    }

    @Override
    public String toString() {
        return "Sphere{" + "Volume=" + calculateVolume() + "radius=" + radius +  '}';
    }
}
