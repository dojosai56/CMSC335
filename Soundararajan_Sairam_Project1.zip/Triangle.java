/**
 * Name: Sairam Soundararajan
 * Date: 10-29-21
 * Course: CMSC335: Object Oriented Programming
 * Project 1
 * Description: The Triangle Class is a TwoDimensionalShape which uses the measurement of a base and height
 * in order to calculate the area.
 */
public class Triangle extends TwoDimensionalShape{

    double base;
    double height;

    public Triangle()
    {
        setBase(0.0);
        setHeight(0.0);
    }

    public Triangle(double base, double height)
    {
        setBase(base);
        setHeight(height);
    }

    public void setBase(double base) {
        this.base = base;
    }

    public void setHeight(double height){
        this.height = height;
    }

    public double getBase() {
        return base;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public double calculateArea() {
        return (getBase() * getHeight()) / 2;
    }

    @Override
    public String toString() {
        return "Triangle{" + "Area=" + calculateArea() + "base=" + base + ", height=" + height + '}';
    }
}
